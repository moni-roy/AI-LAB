lecture(turing,9020).
lecture(turing,9314).
lecture(todd,9311).
lecture(backus,9021).
lecture(ricthie,9201).
lecture(minsky,9414).

study(fred,9020).
study(jack,9311).
study(jill,9314).
study(jill,9414).
study(herry,9414).
study(herry,9314).

year(fred,1).
year(jack,1).
year(jill,1).
year(herry,4).

